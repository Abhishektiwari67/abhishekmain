//
//  afterDetails.swift
//  AT
//
//  Created by Satya on 07/10/21.
//  Copyright © 2021 Brad. All rights reserved.
//

import UIKit

class afterDetails: UIViewController,UINavigationControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = false


        // Do any additional setup after loading the view.
    }
    

    

}
